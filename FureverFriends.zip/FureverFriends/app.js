//filter animals
const searchBar document.forms['search-animals'].querySelector('input');
searchBar.addEventListener('keyup', function(e){

}}